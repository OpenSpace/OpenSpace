#include <openspace/interaction/externalcontrol/externalconnectioncontroller.h>

namespace openspace {
	
ExternalConnectionController::ExternalConnectionController() {
}

ExternalConnectionController::~ExternalConnectionController() {

}

} // namespace openspace